
# In[8]:


#equation for voltage 2
#(V2-V+/R3)+(V2/R4)-Io[(exp((V1-V2)/VT))-1] = 0

import numpy as np
from math import exp

V1, V2 = 1, 0
f1 = V1 + ((15e-6/4)*[(exp((V1-V2)/0.05))-1] - (25/4)
f2 = V2 - ((5e-6)/2)*[(exp((V1-V2)/0.05))-1] - (15/6) 

A = [np.gradient(f1, V2),
     np.gradient(f2, V2)]
Sol = [f1, f2]



def f_1(x):
    return f1
def f_2(x):
    return f2
def df_1(x):
    return np.gradient(f1)
def df_2(x):
    return np.gradient(f2)

def poly1(f_1, df_1, x1, accuracy):
    delta = 1.0
    while abs(delta)>accuracy:
        delta = f_1(x1)/df_1(x1)
        x1 -= delta
    return x1


def poly2(f_2, df_2, x2, accuracy):
    delta = 1.0
    while abs(delta)>accuracy:
        delta = f_2(x2)/df_2(x2)
        x2 -= delta
    return x2



